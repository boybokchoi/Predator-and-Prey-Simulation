#ifndef RANDOM_H
#define RANDOM_H

#include <cstdlib>

class Random
{
public:
    Random();
    int GenRand(int highestNum);

    int randNum;
};

#endif // RANDOM_H
