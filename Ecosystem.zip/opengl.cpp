#include "opengl.h"

openGL::openGL()
{
}
