#ifndef OPENGL_H
#define OPENGL_H

class openGL
{
public:
    openGL();
};

#endif // OPENGL_H
